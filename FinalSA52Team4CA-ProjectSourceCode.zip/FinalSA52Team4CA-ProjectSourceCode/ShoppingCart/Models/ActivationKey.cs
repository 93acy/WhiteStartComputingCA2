﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Models
{
    public class ActivationKey
    {
        public string PurchaseDetailPurchaseId { get; set; }
        public int PurchaseDetailProductId { get; set; }

        [Key]
        public string PdtAtvKey { get; set; }
    }
}
