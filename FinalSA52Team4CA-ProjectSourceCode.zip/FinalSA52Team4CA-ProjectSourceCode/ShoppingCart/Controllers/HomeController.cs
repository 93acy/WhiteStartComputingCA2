﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShoppingCart.Models;
using ShoppingCart.Db;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Controllers
{
    public class HomeController : Controller
    {
        private readonly Database db;

        public HomeController(Database db)
        {
            this.db = db;
        }

        public IActionResult Index(string keyword)
        {
            List<Product> products = default;
            // With search keyword
            if (!string.IsNullOrEmpty(keyword) && !string.IsNullOrEmpty(keyword.Trim()))
            {
                products = db.Products.Where(x => x.Description.ToLower().Contains(keyword.Trim().ToLower()) || x.Name.ToLower().Contains(keyword.Trim().ToLower())).ToList();
                ViewData["searchtext"] = keyword.Trim();
            }
            else
            {
                products = db.Products.ToList();
            }
            ViewData["products"] = products;

            Session session = db.Sessions.FirstOrDefault(x => x.Id == Request.Cookies["sessionId"]);
            User guestUser = db.Users.FirstOrDefault(x => x.Id == Request.Cookies["guestId"]);
            ViewData["numberOfProductsInCart"] = "0";

            // Either session exists or guest user exists (both cannot exists at the same time)
            if ((session != null || guestUser != null) && !(session != null && guestUser != null))
            {
                // Logged in user
                if (session != null)
                {
                    ViewData["username"] = session.User.Username;

                    Cart existingCart = db.Carts.FirstOrDefault(x => (x.UserId == session.UserId));

                    if (existingCart != null)
                    {
                        ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);
                    }

                }

                // Guest user
                else
                {
                    Cart existingCart = db.Carts.FirstOrDefault(x => (x.UserId == guestUser.Id));

                    if (existingCart != null)
                    {
                        ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);
                    }
                }
            }

            // Bolds "Home" as the selected menu item
            ViewData["Is_Home"] = "bold_menu";

            return View();
        }

        [HttpPost]
        public IActionResult UpdateCart([FromBody] UpdateCartInput input)
        {
            Session session = db.Sessions.FirstOrDefault(x => x.Id == Request.Cookies["sessionId"]);
            User guestUser = db.Users.FirstOrDefault(x => x.Id == Request.Cookies["guestId"]);

            if ((session != null || guestUser != null) && !(session != null && guestUser != null))
            {
                if (session != null)
                {
                    // Retrieves existing cart from db
                    Cart existingCart = db.Carts.FirstOrDefault(x => (x.UserId == session.UserId));

                    // No existing cart; Creates new cart for user
                    if (existingCart == null)
                    {
                        Cart newCart = new Cart
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = session.UserId
                        };
                        db.Add(newCart);
                        db.SaveChanges();

                        CartDetail newCartDetail = new CartDetail
                        {
                            CartId = newCart.Id,
                            ProductId = int.Parse(input.ProductId),
                            UserId = session.UserId,
                            Quantity = 1
                        };
                        db.Add(newCartDetail);
                        db.SaveChanges();

                        // Counts number of products in cart 
                        ViewData["numberOfProductsInCart"] = newCart.CartDetails.ToList().Sum(x => x.Quantity);
                    }

                    // Cart exists, retrieves existing cart details
                    else
                    {
                        List<CartDetail> existingCartDetails = existingCart.CartDetails.ToList();

                        // Checks if existing cart already has selected product
                        CartDetail cartDetailWithThisProduct = existingCartDetails.Find(x => x.ProductId == int.Parse(input.ProductId));

                        // If selected product does not exist in cart, create new cart information
                        if (cartDetailWithThisProduct == null)
                        {
                            CartDetail newCartDetail = new CartDetail
                            {
                                CartId = existingCart.Id,
                                ProductId = int.Parse(input.ProductId),
                                UserId = session.UserId,
                                Quantity = 1
                            };
                            db.Add(newCartDetail);
                            db.SaveChanges();

                            ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);
                        }

                        // Selected product already exists, increases quantity by one
                        else
                        {
                            cartDetailWithThisProduct.Quantity = cartDetailWithThisProduct.Quantity + 1;
                            db.SaveChanges();

                            // Updates number of products in cart
                            ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);
                        }
                    }
                }

                else
                {
                    Cart existingCart = db.Carts.FirstOrDefault(x => (x.UserId == guestUser.Id));
                    if (existingCart == null)
                    {
                        Cart newCart = new Cart
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = guestUser.Id
                        };
                        db.Add(newCart);
                        db.SaveChanges();

                        CartDetail newCartDetail = new CartDetail
                        {
                            CartId = newCart.Id,
                            ProductId = int.Parse(input.ProductId),
                            UserId = guestUser.Id,
                            Quantity = 1
                        };
                        db.Add(newCartDetail);
                        db.SaveChanges();

                        ViewData["numberOfProductsInCart"] = newCart.CartDetails.ToList().Sum(x => x.Quantity);
                    }
                    else
                    {
                        List<CartDetail> existingCartDetails = existingCart.CartDetails.ToList();

                        CartDetail cartDetailWithThisProduct = existingCartDetails.Find(x => x.ProductId == int.Parse(input.ProductId));

                        if (cartDetailWithThisProduct == null)
                        {
                            CartDetail newCartDetail = new CartDetail
                            {
                                CartId = existingCart.Id,
                                ProductId = int.Parse(input.ProductId),
                                UserId = guestUser.Id,
                                Quantity = 1
                            };
                            db.Add(newCartDetail);
                            db.SaveChanges();

                            ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);

                        }
                        else
                        {
                            cartDetailWithThisProduct.Quantity = cartDetailWithThisProduct.Quantity + 1;
                            db.SaveChanges();

                            ViewData["numberOfProductsInCart"] = existingCart.CartDetails.ToList().Sum(x => x.Quantity);
                        }
                    }
                }
            }
            return Json(new { status = "success", cartNumber = ViewData["numberOfProductsInCart"].ToString() });
        }
    }
}
