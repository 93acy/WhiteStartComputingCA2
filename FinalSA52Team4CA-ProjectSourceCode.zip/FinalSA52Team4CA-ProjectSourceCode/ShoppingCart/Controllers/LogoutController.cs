﻿using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Db;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Controllers
{
    public class LogoutController : Controller
    {
        private readonly Database db;

        public LogoutController(Database db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {

            // Removes the user's sessionId from database
            string sessionId = HttpContext.Request.Cookies["sessionId"];

            Session currentSession = db.Sessions.FirstOrDefault(x => x.Id == sessionId);
            db.Remove(currentSession);
            db.SaveChanges();

            HttpContext.Response.Cookies.Delete("sessionId");

            // Directs user back to our default home page which displays all products
            return RedirectToAction("Index", "Home");
        }
    }
}