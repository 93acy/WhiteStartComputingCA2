﻿using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Db;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Controllers
{
    public class PurchasesController : Controller
    {
        private readonly Database db;

        public PurchasesController(Database db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            Session session = db.Sessions.FirstOrDefault(x => x.Id == Request.Cookies["sessionId"]);

            // Redirects user back to login page if not logged in
            if (session == null)
            {
                return RedirectToAction("Index", "Login");
            }

            // Retrieves list of past purchases ordered by purchase date
            List<PurchaseDetail> purchases = db.PurchaseDetails.Where(x => x.UserId == session.UserId)
                                                               .OrderBy(x => x.Purchase.Timestamp).ToList();

            // If purchases exist
            if (purchases.Count() > 0)
            {
                // Retrieves list of id of unique products from the purchases
                List<int> pdtIds = new List<int> { purchases[0].ProductId };

                for (int i = 1; i < purchases.Count(); i++)
                {
                    if (!pdtIds.Contains(purchases[i].ProductId))
                    {
                        pdtIds.Add(purchases[i].ProductId);
                    }
                }

                // Group purchases by product id
                List<PurGroupedByPdt> grpPurchases = new List<PurGroupedByPdt>();
                foreach (int pdtId in pdtIds)
                {
                    List<PurchaseDetail> pcWithSamePdtId = (from pc in purchases
                                                            where pc.ProductId == pdtId
                                                            select pc).ToList();

                    int totalquantity = 0;
                    foreach (PurchaseDetail pc in pcWithSamePdtId)
                    {
                        totalquantity += pc.Quantity;
                    }

                    PurGroupedByPdt currentgrp = new PurGroupedByPdt
                    {
                        ProductId = pdtId,
                        PurchasedItems = pcWithSamePdtId,
                        TotalQuantity = totalquantity
                    };

                    grpPurchases.Add(currentgrp);
                }

                ViewData["grpPurchases"] = grpPurchases;

            }


            // To display username
            ViewData["username"] = session.User.Username;

            // Bolds "My Purchases" as the selected menu item
            ViewData["Is_MyPurchases"] = "bold_menu";

            return View();
        }

        [HttpPost]
        public IActionResult GetDate([FromBody] AtvKeyInput input)
        {
            ActivationKey ak = db.ActivationKeys.Where(x => x.PdtAtvKey == input.AtvKey).FirstOrDefault();
            PurchaseDetail p = db.PurchaseDetails.Where(x => x.PurchaseId == ak.PurchaseDetailPurchaseId
                                                && x.ProductId == ak.PurchaseDetailProductId).FirstOrDefault();
            var dateFormat = "dd MMM yyyy";
            DateTimeOffset pdatetime = DateTimeOffset.FromUnixTimeSeconds(p.Purchase.Timestamp).ToLocalTime();
            string pdate = pdatetime.ToString(dateFormat);
            return Json(new { pdate, pdtId = p.ProductId });
        }
    }
}