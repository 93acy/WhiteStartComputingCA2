﻿using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Db;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly Database db;

        public CheckoutController(Database db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            string sessionId = HttpContext.Request.Cookies["sessionId"];
            Session session = db.Sessions.FirstOrDefault(x => x.Id == sessionId);
            if (session == null)
            {
                return RedirectToAction("Index", "Login");
            }
            else
            {
                string userId = session.User.Id;
                Cart cart = db.Carts.FirstOrDefault(x => x.UserId == userId);
                List<CartDetail> cartDetails = cart.CartDetails.ToList();

                var purchaseId = Guid.NewGuid().ToString();
                Purchase purchase = new Purchase
                {
                    Id = purchaseId,
                    UserId = userId,
                    Timestamp = DateTimeOffset.Now.ToUnixTimeSeconds()
                };
                db.Add(purchase);

                foreach (var p in cartDetails)
                {
                    PurchaseDetail purchaseDetail = new PurchaseDetail
                    {
                        PurchaseId = purchaseId,
                        ProductId = p.ProductId,
                        UserId = userId,
                        Quantity = p.Quantity
                    };
                    db.Add(purchaseDetail);

                    for (int i = 1; i <= p.Quantity; i++)
                    {

                        ActivationKey activationKey = new ActivationKey
                        {
                            PurchaseDetailPurchaseId = purchaseId,
                            PurchaseDetailProductId = p.ProductId,
                            PdtAtvKey = Guid.NewGuid().ToString()
                        };
                        db.Add(activationKey);
                    }
                }

                db.Carts.Remove(cart);
                foreach (var p in cartDetails)
                {
                    db.CartDetails.Remove(p);
                }

                db.SaveChanges();

                ViewData["sessionId"] = sessionId;

                // Bolds "My Cart" as the selected menu item
                ViewData["Is_MyCart"] = "bold_menu";

                return RedirectToAction("Index", "Purchases");
            }

        }

    }
}