﻿using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Db
{
    public class DbSeedData
    {
        private readonly Database db;

        public DbSeedData(Database db)
        {
            this.db = db;
        }

        public void Seed()
        {
            AddUsers();
            AddProducts("SeedData/product.data");
            AddPurchases("SeedData/purchases.data");
            AddPurchaseDetails("SeedData/purchasedetails.data");
            AddActivationKeys("SeedData/activationkeys.data");
        }

        public void AddUsers()
        {
            string[] usernameArr = new string[] { "James", "Lily" };
            string[] passwordArr = new string[] { "1234", "4321" };

            for (int i = 0; i < usernameArr.Length; i++)
            {
                db.Add(new User
                {
                    Id = Guid.NewGuid().ToString(),
                    Username = usernameArr[i],
                    Password = passwordArr[i],
                });
            }
            db.SaveChanges();
        }

        public void AddProducts(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            foreach (string line in lines)
            {
                string[] temp = line.Split(";");
                if (temp.Length == 4)
                {
                    db.Products.Add(new Product
                    {
                        Name = temp[0],
                        Description = temp[1],
                        Price = double.Parse(temp[2]),
                        Image = temp[3]
                    });
                }
            }
            db.SaveChanges();
        }

        public void AddPurchases(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            foreach (string line in lines)
            {
                string[] temp = line.Split(";");
                if (temp.Length == 2)
                {
                    User lily = db.Users.Where(x => x.Username == "Lily").FirstOrDefault();
                    db.Purchases.Add(new Purchase
                    {
                        Id = temp[0],
                        Timestamp = long.Parse(temp[1]),
                        UserId = lily.Id
                    });
                }
            }

            db.SaveChanges();
        }

        public void AddPurchaseDetails(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            foreach (string line in lines)
            {
                string[] temp = line.Split(";");
                if (temp.Length == 3)
                {
                    User lily = db.Users.Where(x => x.Username == "Lily").FirstOrDefault();
                    db.PurchaseDetails.Add(new PurchaseDetail
                    {
                        PurchaseId = temp[0],
                        ProductId = int.Parse(temp[1]),
                        Quantity = int.Parse(temp[2]),
                        UserId = lily.Id
                    });
                }
            }

            db.SaveChanges();
        }

        public void AddActivationKeys(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            foreach (string line in lines)
            {
                string[] temp = line.Split(";");
                if (temp.Length == 3)
                {
                    db.ActivationKeys.Add(new ActivationKey
                    {
                        PurchaseDetailPurchaseId = temp[0],
                        PurchaseDetailProductId = int.Parse(temp[1]),
                        PdtAtvKey = temp[2]
                    });
                }
            }
            db.SaveChanges();
        }
    }
}
