﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Db;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Middleware
{
    public class CreateGuestIfNotLoggedIn
    {
        private readonly RequestDelegate next;
        public CreateGuestIfNotLoggedIn(RequestDelegate next)
        {
            this.next = next;
        }
        // HttpContext objects hold information about the current Http request
        public async Task Invoke(HttpContext guestContext, [FromServices] Database db)
        {
            string sessionId = guestContext.Request.Cookies["sessionId"];
            string currentGuestId = guestContext.Request.Cookies["guestId"];

            if (sessionId == null && currentGuestId == null)
            {
                // If there is no session ID and currentGuestId, system automatically assigns a new Id
                User guest = new User { Id = Guid.NewGuid().ToString()};
                db.Add(guest);
                db.SaveChanges();

                // Adds a new cookie
                guestContext.Response.Cookies.Append("guestId", guest.Id);
            }
            await next(guestContext);
        }
    }
}
